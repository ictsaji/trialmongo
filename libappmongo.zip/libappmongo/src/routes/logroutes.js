

const express = require('express');   // basic express import command

const logrouter = express.Router();

function logrouting(nav)
 {


       logrouter.get('/', function (req, res){
                res.render("liblog",{
                nav, 
                title:"library"
        });
        });

        return logrouter;
}



module.exports = logrouting;