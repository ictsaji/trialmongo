const express=require('express');
const adminrouter= express.Router();
const bookdata=require ('../model/bookdata');


function entryroute(nav)
 {


       adminrouter.get('/', function (req, res)
        {
                res.render("addbook",{
                  nav, 
                  title:'library'});
        });

        adminrouter.get('/newbook', function (req, res)
        {
              // res.send( " book added");

               var item= {

               title: req.body.title,
               author: req.body.author,
               genre:req.body.genre,
               image:req.body.image
            }

            var book= bookdata(item);
            book.save();
            res.redirect('/books');

        });


        return adminrouter;
}



module.exports = entryroute;
